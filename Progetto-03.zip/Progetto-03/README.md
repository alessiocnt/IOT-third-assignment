# Smart Dam
## IOT A.A. 2020/2021
### Setup project
Impostare gli indirizzi IP e porte per permettere la comunicazione:
1. Dam service: passare come primo argomento la porta seriale dove si trova arduino, oppure hardcoded alla linea 15 di DamService.java
2. Dam Dashboard: IP del Dam Service alla linea 10 di Main.Java
3. Dam Mobile App: IP e porta(8000) del Dam Service all'interno del file Config.java nel package Utils
4. Remote Hydrometer: Wifi SSID e Wifi PASSWORD linea 16-17 di main.cpp
### Riferimenti
- Simone Ceredi - [simone.ceredi@studio.unibo.it](simone.ceredi@studio.unibo.it)
- Alessio Conti - [alessio.conti3@studio.unibo.it](alessio.conti3@studio.unibo.it)
