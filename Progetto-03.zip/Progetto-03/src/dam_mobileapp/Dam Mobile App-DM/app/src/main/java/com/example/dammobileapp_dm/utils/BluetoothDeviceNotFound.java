package com.example.dammobileapp_dm.utils;

public class BluetoothDeviceNotFound extends Exception { }
