package viewer.view;

public interface View {
	void render();
}
