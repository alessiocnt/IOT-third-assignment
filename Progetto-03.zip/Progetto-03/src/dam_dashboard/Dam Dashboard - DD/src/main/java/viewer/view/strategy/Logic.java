package viewer.view.strategy;

public interface Logic {
	public void execute();
}
