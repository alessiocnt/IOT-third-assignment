ServoTimer2
===========

ServoTimer2 is a simple servo library for Arduino 1.x that does not use Timer1 in case of a conflict.

Original (c) 2008 Michael Margolis, updated for Arduino 1.x and example added by Nick Bontrager 2013.
