package com.example.dammobileapp_dm.utils;

public class Config {
    public static final String URL = "http://192.168.1.48:8000";  // http://192.168.1.48:8000  https://192.168.1.106:8000
}
